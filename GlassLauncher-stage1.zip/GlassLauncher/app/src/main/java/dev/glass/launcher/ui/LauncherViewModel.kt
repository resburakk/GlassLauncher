package dev.glass.launcher.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.glass.launcher.LauncherApp
import dev.glass.launcher.data.AppInfo
import dev.glass.launcher.data.LauncherSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    private val la = app as LauncherApp
    private val sharing = SharingStarted.WhileSubscribed(5_000)

    val settings: StateFlow<LauncherSettings> = la.settingsStore.settings
        .stateIn(viewModelScope, sharing, LauncherSettings())
    val iconCache = la.iconCache

    private val dockPackages = MutableStateFlow<List<String>>(emptyList())

    /** Dock: her paketin ilk başlatılabilir girişi (en fazla 4). */
    val dockApps: StateFlow<List<AppInfo>> =
        combine(la.appRepository.apps, dockPackages) { apps, pkgs ->
            pkgs.mapNotNull { p -> apps.firstOrNull { it.componentName.packageName == p } }.take(4)
        }.stateIn(viewModelScope, sharing, emptyList())

    /** Ana ekran sayfalarındaki uygulamalar: dock'takiler hariç (iOS gibi). */
    val gridApps: StateFlow<List<AppInfo>> =
        combine(la.appRepository.apps, dockApps) { apps, dock ->
            val dockKeys = dock.map { it.key }.toSet()
            apps.filter { it.key !in dockKeys }
        }.stateIn(viewModelScope, sharing, emptyList())

    init {
        viewModelScope.launch(Dispatchers.IO) {
            dockPackages.value = la.appRepository.defaultDockPackages()
        }
    }

    fun launch(app: AppInfo) = la.appRepository.launch(app)
}
