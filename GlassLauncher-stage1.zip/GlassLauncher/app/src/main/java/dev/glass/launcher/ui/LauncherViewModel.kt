package dev.glass.launcher.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.glass.launcher.LauncherApp
import dev.glass.launcher.data.AppInfo
import dev.glass.launcher.data.LauncherSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    private val la = app as LauncherApp
    private val repo = la.appRepository
    private val eager = SharingStarted.WhileSubscribed(5_000)

    val settings: StateFlow<LauncherSettings> = la.settingsStore.settings
        .stateIn(viewModelScope, eager, LauncherSettings())

    /** Dock uygulamaları (şimdilik varsayılanlar; düzenleme modu gelince kalıcı hale gelecek). */
    val dockApps: StateFlow<List<AppInfo>> = repo.apps.map { list ->
        repo.defaultDockPackages
            .mapNotNull { pkg -> list.firstOrNull { it.componentName.packageName == pkg } }
            .take(4)
    }.stateIn(viewModelScope, eager, emptyList())

    /** Dock'ta olmayan uygulamalar ana ekran ızgarasında görünür (iOS davranışı). */
    val gridApps: StateFlow<List<AppInfo>> = combine(repo.apps, dockApps) { all, dock ->
        val keys = dock.map { it.key }.toSet()
        all.filter { it.key !in keys }
    }.stateIn(viewModelScope, eager, emptyList())

    val iconCache = la.iconCache

    fun launch(app: AppInfo) = repo.launch(app)
}
