package dev.glass.launcher.ui

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.glass.launcher.data.LauncherSettings

/**
 * iPhone (393pt genişlik) ölçülerinden türetilen oranlar:
 * simge 60pt (0.1527), yatay adım 90pt (0.229), satır adımı ~96pt (x1.07), sol kenar ~31pt (0.08).
 * Bu değerler iOS 26 ekranından göz kararı alınmış yaklaşık oranlardır; cihazda ince ayar gerekebilir.
 */
data class HomeMetrics(
    val columns: Int,
    val rows: Int,
    val icon: Dp,
    val pitchX: Dp,
    val pitchY: Dp,
    val marginX: Dp,
    val topPad: Dp,
    val dockReserve: Dp,
) {
    val perPage: Int get() = columns * rows

    companion object {
        val IndicatorHeight = 28.dp

        fun compute(width: Dp, height: Dp, s: LauncherSettings): HomeMetrics {
            val cols = s.columns
            val f = 4f / cols
            val pitchX = width * 0.229f * f
            val icon = (width * 0.1527f * f * s.iconScale).coerceAtMost(pitchX * 0.92f)
            val marginX = (width - icon - pitchX * (cols - 1)) / 2f
            val pitchY = pitchX * 1.07f
            val topPad = width * 0.04f
            val dockReserve = width * 0.27f // Aşama 3'te dock buraya oturacak
            val free = height - topPad - dockReserve - IndicatorHeight
            val rows = (free / pitchY).toInt().coerceIn(1, s.rows)
            return HomeMetrics(cols, rows, icon, pitchX, pitchY, marginX, topPad, dockReserve)
        }
    }
}
