package dev.glass.launcher

import android.app.Application
import dev.glass.launcher.data.AppRepository
import dev.glass.launcher.data.IconCache
import dev.glass.launcher.data.SettingsStore

class LauncherApp : Application() {
    lateinit var appRepository: AppRepository
        private set
    lateinit var iconCache: IconCache
        private set
    lateinit var settingsStore: SettingsStore
        private set

    override fun onCreate() {
        super.onCreate()
        appRepository = AppRepository(this)
        iconCache = IconCache()
        settingsStore = SettingsStore(this)
        appRepository.start()
    }
}
