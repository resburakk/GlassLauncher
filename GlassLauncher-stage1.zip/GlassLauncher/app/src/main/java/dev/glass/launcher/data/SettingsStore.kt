package dev.glass.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "launcher_settings")

data class LauncherSettings(
    val columns: Int = 4,
    val rows: Int = 6,
    val showLabels: Boolean = true,
    val iconScale: Float = 1f,
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val columns = intPreferencesKey("columns")
        val rows = intPreferencesKey("rows")
        val showLabels = booleanPreferencesKey("show_labels")
        val iconScale = floatPreferencesKey("icon_scale")
    }

    val settings: Flow<LauncherSettings> = context.dataStore.data.map { p: Preferences ->
        val d = LauncherSettings()
        LauncherSettings(
            columns = (p[Keys.columns] ?: d.columns).coerceIn(3, 6),
            rows = (p[Keys.rows] ?: d.rows).coerceIn(4, 8),
            showLabels = p[Keys.showLabels] ?: d.showLabels,
            iconScale = (p[Keys.iconScale] ?: d.iconScale).coerceIn(0.7f, 1.3f),
        )
    }

    suspend fun update(block: (LauncherSettings) -> LauncherSettings) {
        context.dataStore.edit { p ->
            val cur = LauncherSettings(
                p[Keys.columns] ?: 4, p[Keys.rows] ?: 6,
                p[Keys.showLabels] ?: true, p[Keys.iconScale] ?: 1f,
            )
            val n = block(cur)
            p[Keys.columns] = n.columns; p[Keys.rows] = n.rows
            p[Keys.showLabels] = n.showLabels; p[Keys.iconScale] = n.iconScale
        }
    }
}
