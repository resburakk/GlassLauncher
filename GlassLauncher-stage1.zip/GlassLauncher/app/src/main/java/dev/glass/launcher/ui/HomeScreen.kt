package dev.glass.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.glass.launcher.R
import dev.glass.launcher.data.AppInfo

/** AŞAMA 1: altyapıyı doğrulayan sade sayfalı ızgara. Liquid Glass tasarımı Aşama 2-3'te gelir. */
@Composable
fun HomeScreen(vm: LauncherViewModel, isDefaultHome: Boolean, onRequestDefault: () -> Unit) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    // Ana ekranda Geri tuşu hiçbir şey yapmamalı.
    BackHandler(enabled = true) {}

    val perPage = settings.columns * settings.rows
    val pages = apps.chunked(perPage)
    val pagerState = rememberPagerState { maxOf(pages.size, 1) }

    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        if (!isDefaultHome) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x66000000))
                    .padding(14.dp)
            ) {
                Text(stringResource(R.string.make_default_hint), color = Color.White, fontSize = 13.sp)
                Button(onClick = onRequestDefault) { Text(stringResource(R.string.make_default)) }
            }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
            val items = pages.getOrNull(page).orEmpty()
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                items.chunked(settings.columns).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { app ->
                            AppCell(app, vm, settings.showLabels, settings.iconScale, settings.columns)
                        }
                        repeat(settings.columns - row.size) { Box(Modifier.size(1.dp)) }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(pagerState.pageCount) { i ->
                Box(
                    Modifier.padding(3.dp).size(7.dp).clip(CircleShape)
                        .background(if (i == pagerState.currentPage) Color.White else Color(0x66FFFFFF))
                )
            }
        }
    }
}

@Composable
private fun AppCell(app: AppInfo, vm: LauncherViewModel, showLabel: Boolean, scale: Float, columns: Int) {
    val density = LocalDensity.current
    val iconDp = 60.dp * scale * (4f / columns).coerceAtMost(1.2f)
    val px = with(density) { iconDp.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, app.key, px) { value = vm.iconCache.get(app, px) }

    Column(
        Modifier.clickable { vm.launch(app) }.padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(iconDp).clip(RoundedCornerShape(iconDp * 0.225f))) {
            bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
        }
        if (showLabel) {
            Text(
                app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp).width(iconDp + 8.dp).height(16.dp)
            )
        }
    }
}
