package dev.glass.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.glass.launcher.R
import dev.glass.launcher.data.AppInfo

/** AŞAMA 3a: iOS oranlarında sayfalı ana ekran + cam görünümlü dock. Klasörler ve düzenleme modu sırada. */
@Composable
fun HomeScreen(vm: LauncherViewModel, isDefaultHome: Boolean, onRequestDefault: () -> Unit) {
    val apps by vm.gridApps.collectAsStateWithLifecycle()
    val dockApps by vm.dockApps.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    BackHandler(enabled = true) {} // Ana ekranda Geri tuşu bir şey yapmaz

    BoxWithConstraints(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val m = HomeMetrics.compute(maxWidth, maxHeight, settings)
        val pages = apps.chunked(m.perPage)
        val pagerState = rememberPagerState { maxOf(pages.size, 1) }

        Column(Modifier.fillMaxSize()) {
            if (!isDefaultHome) {
                Column(
                    Modifier
                        .padding(12.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x66000000))
                        .padding(14.dp)
                ) {
                    Text(stringResource(R.string.make_default_hint), color = Color.White, fontSize = 13.sp)
                    Button(onClick = onRequestDefault) { Text(stringResource(R.string.make_default)) }
                }
            }

            Spacer(Modifier.height(m.topPad))

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                val items = pages.getOrNull(page).orEmpty()
                // Üstten hizalı sabit ızgara: son sayfada eksik satırlar boş kalır, simgeler yayılmaz.
                Column(Modifier.fillMaxSize().padding(start = m.marginX)) {
                    items.chunked(m.columns).forEach { row ->
                        Row(
                            Modifier.height(m.pitchY),
                            horizontalArrangement = Arrangement.spacedBy(m.pitchX - m.icon)
                        ) {
                            row.forEach { app ->
                                AppCell(app, vm, m.icon, m.pitchX, m.pitchY, settings.showLabels)
                            }
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().height(HomeMetrics.IndicatorHeight),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(pagerState.pageCount) { i ->
                    Box(
                        Modifier.padding(3.dp).size(7.dp).clip(CircleShape)
                            .background(if (i == pagerState.currentPage) Color.White else Color(0x66FFFFFF))
                    )
                }
            }

            Box(Modifier.fillMaxWidth().height(m.dockReserve), contentAlignment = Alignment.TopCenter) {
                GlassDock(dockApps, vm, m)
            }
        }
    }
}

/**
 * Cam görünümlü dock. Not: Android, başka katmanların (duvar kâğıdı dahil) arkasını bulanıklaştırmaya
 * izin vermez; bu yüzden cam etkisi yarı saydam gradyan, ince kenar ışığı ve gölgeyle çizilir.
 */
@Composable
private fun GlassDock(apps: List<AppInfo>, vm: LauncherViewModel, m: HomeMetrics) {
    val shape = RoundedCornerShape(m.dockH * 0.38f)
    Box(
        Modifier
            .padding(horizontal = m.dockMarginX)
            .fillMaxWidth()
            .height(m.dockH)
            .shadow(14.dp, shape, clip = false, ambientColor = Color(0x33000000), spotColor = Color(0x33000000))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x4DFFFFFF), Color(0x26FFFFFF))))
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color(0xAAFFFFFF), Color(0x1AFFFFFF), Color(0x66FFFFFF))),
                shape
            )
    ) {
        Row(
            Modifier.fillMaxSize().padding(start = m.dockInnerStart),
            horizontalArrangement = Arrangement.spacedBy(m.dockPitch - m.dockIcon),
            verticalAlignment = Alignment.CenterVertically
        ) {
            apps.forEach { app -> AppCell(app, vm, m.dockIcon, m.dockPitch, m.dockIcon, showLabel = false) }
        }
    }
}

private val LabelStyle = TextStyle(
    color = Color.White,
    fontSize = 11.sp,
    fontWeight = FontWeight.Medium,
    textAlign = TextAlign.Center,
    shadow = Shadow(Color(0x66000000), Offset(0f, 1f), 4f),
)

@Composable
private fun AppCell(
    app: AppInfo, vm: LauncherViewModel,
    icon: Dp, pitchX: Dp, cellHeight: Dp, showLabel: Boolean,
) {
    val px = with(LocalDensity.current) { icon.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, app.key, px) { value = vm.iconCache.get(app, px) }

    // Hücre simge genişliğinde; içerik (etiket) yatay adım genişliğine taşar ve ortalanır.
    Box(Modifier.width(icon).height(cellHeight), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.requiredWidth(pitchX).clickable { vm.launch(app) },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(icon).clip(RoundedCornerShape(icon * 0.225f))) {
                bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
            }
            if (showLabel) {
                Text(
                    app.label,
                    style = LabelStyle,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 5.dp, start = 4.dp, end = 4.dp).fillMaxWidth()
                )
            }
        }
    }
}
