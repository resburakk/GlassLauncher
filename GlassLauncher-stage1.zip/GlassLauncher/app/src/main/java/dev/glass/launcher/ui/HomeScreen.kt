package dev.glass.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.glass.launcher.R
import dev.glass.launcher.data.AppInfo

/** AŞAMA 2-3A: iOS oranlarında sayfalı ana ekran. Dock, klasör ve cam efektleri Aşama 3'te. */
@Composable
fun HomeScreen(vm: LauncherViewModel, isDefaultHome: Boolean, onRequestDefault: () -> Unit) {
    val apps by vm.gridApps.collectAsStateWithLifecycle()
    val dock by vm.dockApps.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    BackHandler(enabled = true) {} // Ana ekranda Geri tuşu bir şey yapmaz

    BoxWithConstraints(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val m = HomeMetrics.compute(maxWidth, maxHeight, settings)
        val pages = apps.chunked(m.perPage)
        val pagerState = rememberPagerState { maxOf(pages.size, 1) }

        Column(Modifier.fillMaxSize()) {
            if (!isDefaultHome) {
                Column(
                    Modifier
                        .padding(12.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x66000000))
                        .padding(14.dp)
                ) {
                    Text(stringResource(R.string.make_default_hint), color = Color.White, fontSize = 13.sp)
                    Button(onClick = onRequestDefault) { Text(stringResource(R.string.make_default)) }
                }
            }

            Spacer(Modifier.height(m.topPad))

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                val items = pages.getOrNull(page).orEmpty()
                // Üstten hizalı sabit ızgara: son sayfada eksik satırlar boş kalır, simgeler yayılmaz.
                Column(Modifier.fillMaxSize().padding(start = m.marginX)) {
                    items.chunked(m.columns).forEach { row ->
                        Row(
                            Modifier.height(m.pitchY),
                            horizontalArrangement = Arrangement.spacedBy(m.pitchX - m.icon)
                        ) {
                            row.forEach { app -> AppCell(app, vm, m, settings.showLabels) }
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().height(HomeMetrics.IndicatorHeight),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(pagerState.pageCount) { i ->
                    Box(
                        Modifier.padding(3.dp).size(7.dp).clip(CircleShape)
                            .background(if (i == pagerState.currentPage) Color.White else Color(0x66FFFFFF))
                    )
                }
            }

            Box(Modifier.fillMaxWidth().height(m.dockReserve), contentAlignment = Alignment.Center) {
                Dock(dock, vm, m, maxWidth)
            }
        }
    }
}

private val LabelStyle = TextStyle(
    color = Color.White,
    fontSize = 11.sp,
    fontWeight = FontWeight.Medium,
    textAlign = TextAlign.Center,
    shadow = Shadow(Color(0x66000000), Offset(0f, 1f), 4f),
)

@Composable
private fun AppCell(app: AppInfo, vm: LauncherViewModel, m: HomeMetrics, showLabel: Boolean) {
    val px = with(LocalDensity.current) { m.icon.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, app.key, px) { value = vm.iconCache.get(app, px) }

    // Hücre simge genişliğinde; içerik (etiket) yatay adım genişliğine taşar ve ortalanır.
    Box(Modifier.width(m.icon).height(m.pitchY), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.requiredWidth(m.pitchX).clickable { vm.launch(app) },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(m.icon).clip(RoundedCornerShape(m.icon * 0.225f))) {
                bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
            }
            if (showLabel) {
                Text(
                    app.label,
                    style = LabelStyle,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 5.dp, start = 4.dp, end = 4.dp).fillMaxWidth()
                )
            }
        }
    }
}


/**
 * iOS tarzı dock: yuvarlatılmış yarı saydam cam yüzey + ince kenar parlaması.
 * Not: arkadaki duvar kâğıdını gerçekten bulanıklaştırmaz (Compose'ta arka plan bulanıklığı yok);
 * gerçek bulanıklık ve kırılma Aşama 6'da ele alınacak.
 */
@Composable
private fun Dock(apps: List<AppInfo>, vm: LauncherViewModel, m: HomeMetrics, width: Dp) {
    val shape = RoundedCornerShape(width * 0.095f)
    Row(
        Modifier
            .width(width * 0.94f)
            .height(m.icon + width * 0.08f)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x47FFFFFF), Color(0x1FFFFFFF))))
            .border(1.dp, Brush.verticalGradient(listOf(Color(0xA6FFFFFF), Color(0x14FFFFFF))), shape),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 4 sabit yuva: eksik uygulama olsa bile diğerleri yerinde kalır.
        repeat(4) { i ->
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                apps.getOrNull(i)?.let { DockIcon(it, vm, m) }
            }
        }
    }
}

@Composable
private fun DockIcon(app: AppInfo, vm: LauncherViewModel, m: HomeMetrics) {
    val px = with(LocalDensity.current) { m.icon.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, app.key, px) { value = vm.iconCache.get(app, px) }
    Box(
        Modifier.size(m.icon).clip(RoundedCornerShape(m.icon * 0.225f)).clickable { vm.launch(app) }
    ) {
        bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
    }
}
