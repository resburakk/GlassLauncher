package dev.glass.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.blur
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.glass.launcher.R
import dev.glass.launcher.data.AppInfo
import dev.glass.launcher.data.LauncherSettings
import kotlinx.coroutines.delay

enum class Overlay { None, Search, Control, Settings }

/**
 * AŞAMA 3b: ana ekran + cam dock + arama hapı, Spotlight benzeri arama, Kontrol paneli ve ayarlar sayfası.
 * Hareketler: boş alanda aşağı kaydır = arama, üst bölgeden aşağı kaydır = panel, uzun bas = ayarlar.
 */
@Composable
fun HomeScreen(vm: LauncherViewModel, isDefaultHome: Boolean, onRequestDefault: () -> Unit) {
    val gridApps by vm.gridApps.collectAsStateWithLifecycle()
    val allApps by vm.apps.collectAsStateWithLifecycle()
    val dockApps by vm.dockApps.collectAsStateWithLifecycle()
    val recents by vm.recentApps.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    var overlay by remember { mutableStateOf(Overlay.None) }
    val overlayNow by rememberUpdatedState(overlay)
    val blur by animateDpAsState(if (overlay == Overlay.None) 0.dp else 22.dp, tween(260), label = "blur")
    val scrim by animateFloatAsState(if (overlay == Overlay.None) 0f else 0.35f, tween(260), label = "scrim")

    BackHandler(enabled = true) { overlay = Overlay.None } // Ana ekranda Geri tuşu yalnızca katmanları kapatır

    val density = LocalDensity.current
    val topInsetPx = WindowInsets.statusBars.getTop(density)
    val topZonePx = topInsetPx + with(density) { 72.dp.toPx() }
    val suggestions = remember(recents, allApps) { (recents + allApps).distinctBy { it.key }.take(4) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { if (overlayNow == Overlay.None) overlay = Overlay.Settings })
            }
            .pointerInput(topZonePx) {
                var startY = 0f
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { startY = it.y; total = 0f },
                    onDragEnd = {
                        if (overlayNow == Overlay.None && total > 80.dp.toPx()) {
                            overlay = if (startY < topZonePx) Overlay.Control else Overlay.Search
                        }
                        total = 0f
                    },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            }
    ) {
        Box(Modifier.fillMaxSize().then(if (blur > 0.dp) Modifier.blur(blur) else Modifier)) {
            HomeContent(
                vm, gridApps, dockApps, settings, isDefaultHome, onRequestDefault,
                onOpenSearch = { overlay = Overlay.Search },
            )
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = scrim)))

        AnimatedVisibility(
            overlay == Overlay.Search,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.96f),
            exit = fadeOut(tween(140)),
        ) {
            SearchOverlay(
                vm, allApps, suggestions, settings.glassStrength, settings.iconGlass,
                onClose = { overlay = Overlay.None },
            )
        }
        AnimatedVisibility(
            overlay == Overlay.Control,
            enter = slideInVertically { -it / 2 } + fadeIn(tween(200)),
            exit = slideOutVertically { -it / 2 } + fadeOut(tween(160)),
        ) {
            ControlPanel(settings.glassStrength, onClose = { overlay = Overlay.None })
        }
        AnimatedVisibility(
            overlay == Overlay.Settings,
            enter = slideInVertically { it } + fadeIn(tween(200)),
            exit = slideOutVertically { it } + fadeOut(tween(160)),
        ) {
            SettingsSheet(settings, onChange = { vm.updateSettings(it) }, onClose = { overlay = Overlay.None })
        }
    }
}

@Composable
private fun HomeContent(
    vm: LauncherViewModel,
    apps: List<AppInfo>,
    dockApps: List<AppInfo>,
    settings: LauncherSettings,
    isDefaultHome: Boolean,
    onRequestDefault: () -> Unit,
    onOpenSearch: () -> Unit,
) {
    BoxWithConstraints(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.displayCutout))
    ) {
        val m = HomeMetrics.compute(maxWidth, maxHeight, settings)
        val pages = apps.chunked(m.perPage)
        val pagerState = rememberPagerState { maxOf(pages.size, 1) }

        // Sayfa kaydırılırken noktalar, durunca arama hapı görünür (iOS 16+ davranışı).
        var showDots by remember { mutableStateOf(false) }
        LaunchedEffect(pagerState.isScrollInProgress) {
            if (pagerState.isScrollInProgress) showDots = true else { delay(900); showDots = false }
        }
        val dotsAlpha by animateFloatAsState(if (showDots) 1f else 0f, tween(220), label = "dots")

        Column(Modifier.fillMaxSize()) {
            if (!isDefaultHome) {
                Column(
                    Modifier
                        .padding(12.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x66000000))
                        .padding(14.dp)
                ) {
                    Text(stringResource(R.string.make_default_hint), color = Color.White, fontSize = 13.sp)
                    Button(onClick = onRequestDefault) { Text(stringResource(R.string.make_default)) }
                }
            }

            Spacer(Modifier.height(m.topPad))

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                val items = pages.getOrNull(page).orEmpty()
                // Üstten hizalı sabit ızgara: son sayfada eksik satırlar boş kalır, simgeler yayılmaz.
                Column(Modifier.fillMaxSize().padding(start = m.marginX)) {
                    items.chunked(m.columns).forEach { row ->
                        Row(
                            Modifier.height(m.pitchY),
                            horizontalArrangement = Arrangement.spacedBy(m.pitchX - m.icon)
                        ) {
                            row.forEach { app ->
                                AppCell(
                                    app, vm, m.icon, m.pitchX, m.pitchY, settings.showLabels,
                                    settings.iconGlass, settings.glassStrength,
                                ) { vm.launch(app) }
                            }
                        }
                    }
                }
            }

            Box(
                Modifier.fillMaxWidth().height(HomeMetrics.IndicatorHeight),
                contentAlignment = Alignment.Center
            ) {
                Row(Modifier.graphicsLayer { alpha = dotsAlpha }) {
                    repeat(pagerState.pageCount) { i ->
                        Box(
                            Modifier.padding(3.dp).size(7.dp).clip(CircleShape)
                                .background(if (i == pagerState.currentPage) Color.White else Color(0x66FFFFFF))
                        )
                    }
                }
                SearchPill(m, settings.glassStrength, 1f - dotsAlpha, onOpenSearch)
            }

            Box(Modifier.fillMaxWidth().height(m.dockReserve), contentAlignment = Alignment.TopCenter) {
                GlassDock(dockApps, vm, m, settings)
            }
        }
    }
}

@Composable
private fun SearchPill(m: HomeMetrics, strength: Float, alpha: Float, onClick: () -> Unit) {
    Row(
        Modifier
            .graphicsLayer { this.alpha = alpha }
            .width(m.pillW)
            .height(m.pillH)
            .liquidGlass(CircleShape, strength * 0.8f, 6.dp)
            .then(if (alpha > 0.5f) Modifier.clickable(onClick = onClick) else Modifier),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SearchGlyph(Color.White, 14.dp)
        Spacer(Modifier.width(6.dp))
        Text("Ara", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GlassDock(apps: List<AppInfo>, vm: LauncherViewModel, m: HomeMetrics, s: LauncherSettings) {
    Box(
        Modifier
            .padding(horizontal = m.dockMarginX)
            .fillMaxWidth()
            .height(m.dockH)
            .liquidGlass(RoundedCornerShape(m.dockH * 0.38f), s.glassStrength, 14.dp)
    ) {
        Row(
            Modifier.fillMaxSize().padding(start = m.dockInnerStart),
            horizontalArrangement = Arrangement.spacedBy(m.dockPitch - m.dockIcon),
            verticalAlignment = Alignment.CenterVertically
        ) {
            apps.forEach { app ->
                AppCell(
                    app, vm, m.dockIcon, m.dockPitch, m.dockIcon, false,
                    s.iconGlass, s.glassStrength,
                ) { vm.launch(app) }
            }
        }
    }
}

private val LabelStyle = TextStyle(
    color = Color.White,
    fontSize = 11.sp,
    fontWeight = FontWeight.Medium,
    textAlign = TextAlign.Center,
    shadow = Shadow(Color(0x66000000), Offset(0f, 1f), 4f),
)

@Composable
internal fun AppIconImage(app: AppInfo, vm: LauncherViewModel, icon: Dp, glass: Boolean, strength: Float) {
    val px = with(LocalDensity.current) { icon.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, app.key, px) { value = vm.iconCache.get(app, px) }
    Box(Modifier.size(icon).glassIcon(RoundedCornerShape(icon * 0.225f), glass, strength)) {
        bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
    }
}

@Composable
internal fun AppCell(
    app: AppInfo, vm: LauncherViewModel,
    icon: Dp, pitchX: Dp, cellHeight: Dp, showLabel: Boolean,
    glass: Boolean, strength: Float, onClick: () -> Unit,
) {
    // Hücre simge genişliğinde; içerik (etiket) yatay adım genişliğine taşar ve ortalanır.
    Box(Modifier.width(icon).height(cellHeight), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.requiredWidth(pitchX).clickable(onClick = onClick),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppIconImage(app, vm, icon, glass, strength)
            if (showLabel) {
                Text(
                    app.label,
                    style = LabelStyle,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 5.dp, start = 4.dp, end = 4.dp).fillMaxWidth()
                )
            }
        }
    }
}
